<?php
include_once('connects.php');

// Get values from request (use POST in production for security)
$username = $_GET['username'] ?? '';
$password = $_GET['password'] ?? '';
$role     = $_GET['role'] ?? 'user'; // default role is "user"

// Sanitize inputs
$username = mysqli_real_escape_string($con, $username);
$password = mysqli_real_escape_string($con, $password);
$role     = mysqli_real_escape_string($con, $role);

// Check if username already exists
$checkQuery = "SELECT * FROM users WHERE username='$username'";
$checkResult = mysqli_query($con, $checkQuery);

if (mysqli_num_rows($checkResult) > 0) {
    echo json_encode([
        "status" => "exists",
        "message" => "A record with username '$username' already exists"
    ]);
} else {
    // Hash password before storing
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Insert new record
    $insertQuery = "INSERT INTO users (username, password, role) VALUES ('$username', '$hashedPassword', '$role')";
    if (mysqli_query($con, $insertQuery)) {
        echo json_encode([
            "status" => "success",
            "message" => "User registered successfully"
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to insert record: " . mysqli_error($con)
        ]);
    }
}
?>
