<?php
include_once('connects.php');

header('Content-Type: application/json');

// Use POST for security
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

$username = mysqli_real_escape_string($con, $username);

// Look up the user
$query = "SELECT * FROM users WHERE username='$username' LIMIT 1";
$result = mysqli_query($con, $query);

if ($row = mysqli_fetch_assoc($result)) {
    $hashedPassword = $row['password']; // stored hash from DB

    // Verify plain password against hash
    if (password_verify($password, $hashedPassword)) {
        echo json_encode([
            "status" => "success",
            "message" => "Login successful",
            "role" => $row['role']
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Invalid password"
        ]);
    }
} else {
    echo json_encode([
        "status" => "error",
        "message" => "User not found"
    ]);
}
?>
