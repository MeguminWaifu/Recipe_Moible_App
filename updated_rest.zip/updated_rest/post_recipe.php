<?php
include_once('connects.php');

// Get values from request (use POST in production for security)
$food_name    = $_POST['food_name'] ?? '';
$food_type    = $_POST['food_type'] ?? '';
$author_id    = $_POST['author_id'] ?? '';
$img_url      = $_POST['img_url'] ?? '';
$title        = $_POST['title'] ?? '';
$description  = $_POST['description'] ?? '';
$ingredients  = $_POST['ingredients'] ?? '';     // expect JSON or comma-separated list
$instructions = $_POST['instructions'] ?? '';    // expect JSON or comma-separated list
$difficulty   = $_POST['difficulty'] ?? 'easy';  // enum: easy, medium, hard
$is_favorite  = $_POST['is_favorite'] ?? 0;      // default false

// Sanitize inputs
$food_name    = mysqli_real_escape_string($con, $food_name);
$food_type    = mysqli_real_escape_string($con, $food_type);
$author_id    = mysqli_real_escape_string($con, $author_id);
$img_url      = mysqli_real_escape_string($con, $img_url);
$title        = mysqli_real_escape_string($con, $title);
$description  = mysqli_real_escape_string($con, $description);
$ingredients  = mysqli_real_escape_string($con, $ingredients);
$instructions = mysqli_real_escape_string($con, $instructions);
$difficulty   = mysqli_real_escape_string($con, $difficulty);
$is_favorite  = mysqli_real_escape_string($con, $is_favorite);

// Insert new recipe record
$insertQuery = "
    INSERT INTO recipe (
        food_name, food_type, author_id, img_url,
        title, description, ingredients, instructions,
        difficulty, is_favorite
    ) VALUES (
        '$food_name', '$food_type', '$author_id', '$img_url',
        '$title', '$description', '$ingredients', '$instructions',
        '$difficulty', '$is_favorite'
    )
";

if (mysqli_query($con, $insertQuery)) {
    echo json_encode([
        "status" => "success",
        "message" => "Recipe uploaded successfully"
    ]);
} else {
    echo json_encode([
        "status" => "error",
        "message" => "Failed to insert recipe: " . mysqli_error($con)
    ]);
}
?>
